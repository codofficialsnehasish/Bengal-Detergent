<?php $this->load->view('admin/partials/topbar');?>
<?php $this->load->view('admin/partials/sidebar');?>

<!-- @@include("horizontal.html") -->