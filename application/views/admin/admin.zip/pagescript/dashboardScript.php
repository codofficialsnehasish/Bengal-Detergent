 <!-- Peity chart-->
 <script src="<?= base_url('assets/admin/libs/peity/jquery.peity.min.js');?>"></script>
    
    <!-- Plugin Js-->
    <script src="<?= base_url('assets/admin/libs/chartist/chartist.min.js');?>"></script>
    <script src="<?= base_url('assets/admin/libs/chartist-plugin-tooltips/chartist-plugin-tooltip.min.js');?>"></script>

    <script src="<?= base_url('assets/admin/js/pages/dashboard.init.js');?>"></script>