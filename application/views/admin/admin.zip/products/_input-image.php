    <div class="card">
        <div class="card-header bg-primary text-light">
            Size Chart
        </div>
        <div class="card-body text-center">
            <div class="mb-0">
                <img class="img-thumbnail rounded me-2" id="blah" alt="" width="200" src="" data-holder-rendered="true" style="display: none;">
            </div>
            <div class="mb-0">
                <input type="file" name="file" class="filestyle" id="imgInp" data-input="false" data-buttonname="btn-secondary">
                <input type="hidden" name="media_id" id="media_id" />
                <a href="javascript:;" id="openLibrary">or Choose From Library</a>
            </div> 
        </div>
    </div>