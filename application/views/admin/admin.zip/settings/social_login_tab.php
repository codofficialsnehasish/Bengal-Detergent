<ul class="nav nav-tabs" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link <?= tab_active('')?>"  href="<?= admin_url('social-login-settings');?>" role="tab">
                                                    <span class="d-none d-md-block">Google</span><span class="d-block d-md-none"><i class="mdi mdi-home-variant h5"></i></span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link  <?= tab_active('facebook-settings')?>"  href="<?= admin_url('social-login-settings/facebook-settings');?>" role="tab">
                                                    <span class="d-none d-md-block">Facebook</span><span class="d-block d-md-none"><i class="mdi mdi-account h5"></i></span>
                                                </a>
                                            </li>
                                           
                                            
                                        </ul>
