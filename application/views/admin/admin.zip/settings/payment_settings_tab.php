<ul class="nav nav-tabs" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link <?= tab_active('razorpay')?>"  href="<?= admin_url('payment-settings/razorpay');?>" role="tab">
                                                    <span class="d-none d-md-block">Razorpay</span><span class="d-block d-md-none"><i class="mdi mdi-home-variant h5"></i></span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link  <?= tab_active('payu-settings')?>"  href="<?= admin_url('payment-settings/payu-settings');?>" role="tab">
                                                    <span class="d-none d-md-block">PayU</span><span class="d-block d-md-none"><i class="mdi mdi-account h5"></i></span>
                                                </a>
                                            </li>
                                           
                                            
                                        </ul>
