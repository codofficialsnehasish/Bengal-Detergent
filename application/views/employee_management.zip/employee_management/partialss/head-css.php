<link href="<?= base_url('assets/admin/libs/dropzone/min/dropzone.min.css');?>" rel="stylesheet" type="text/css">

<!-- Bootstrap Css -->
<link href="<?= base_url('assets/admin/css/bootstrap.min.css');?>" id="bootstrap-style" rel="stylesheet" type="text/css">
<!-- Icons Css -->
<link href="<?= base_url('assets/admin/css/icons.min.css');?>" rel="stylesheet" type="text/css">
<!-- App Css-->
<link href="<?= base_url('assets/admin/css/app.min.css');?>" id="app-style" rel="stylesheet" type="text/css">


<!-- Toast message -->
<link href="<?= base_url('assets/admin/libs/toast/toastr.css');?>" rel="stylesheet" type="text/css" />
<!-- Toast message -->
<link href="<?= base_url('assets/admin/libs/select2/css/select2.min.css');?>" rel="stylesheet" type="text/css">
<link href="<?= base_url('assets/admin/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css');?>" rel="stylesheet">

<style>
    div#v-pills-tab {
        background: #00000003;
        text-align: left;
    }

    div#v-pills-tab button {
        text-align: left;
    }

    input[switch]+label {
        width: 75px !important;
    }

    input[switch]:checked+label:after {
        left: 53px !important;
    }
    
    input[switch]+label:before {
        top: -1px !important;
    }
</style>