<?php $this->load->view('employee_management/partialss/inner-footer');?>
                
                </div>
                <!-- end main content-->
    
            </div>
            <!-- END layout-wrapper -->
            <?php $this->load->view('employee_management/partialss/right-sidebar');?>
            
    
            <?php $this->load->view('employee_management/partialss/vendor-script');?>
             
            <script src="<?= base_url('assets/admin/js/app.js');?>"></script>
            <?php $this->load->view('employee_management/partialss/mediaUpload');?>
</body>
    
</html>