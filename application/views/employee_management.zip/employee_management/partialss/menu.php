<?php $this->load->view('employee_management/partialss/topbar');?>
<?php $this->load->view('employee_management/partialss/sidebar');?>

<!-- @@include("horizontal.html") -->