<link rel="stylesheet" href="<?= base_url('assets/admin/codemirror/lib/codemirror.css');?>">

<link rel="stylesheet" href="<?= base_url('assets/admin/codemirror/theme/midnight.css');?>">
<script src="<?= base_url('assets/admin/codemirror/lib/codemirror.js');?>"></script>
<script src="<?= base_url('assets/admin/codemirror/mode/javascript/javascript.js');?>"></script>
<script src="<?= base_url('assets/admin/codemirror/mode/css/css.js');?>"></script>
<script src="<?= base_url('assets/admin/codemirror/addon/selection/active-line.js');?>"></script>
<script src="<?= base_url('assets/admin/codemirror/addon/edit/matchbrackets.js');?>"></script>
