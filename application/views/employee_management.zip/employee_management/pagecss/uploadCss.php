<link href="<?= base_url('assets/admin/libs/dropzone/min/dropzone.min.css');?>" rel="stylesheet" type="text/css">
        <link href="<?= base_url('assets/admin/libs/sweetalert2/sweetalert2.min.css');?>" rel="stylesheet" type="text/css" />
        <link href="<?= base_url('assets/admin/libs/spectrum-colorpicker2/spectrum.min.css');?>" rel="stylesheet" type="text/css">
