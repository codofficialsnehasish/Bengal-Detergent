        <!-- Lightbox css -->
        <link href="<?= base_url('assets/admin/libs/magnific-popup/magnific-popup.css');?>" rel="stylesheet" type="text/css" />
