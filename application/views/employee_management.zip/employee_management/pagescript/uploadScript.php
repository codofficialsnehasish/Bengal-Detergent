        <!-- Plugins js -->
        <script src="<?= base_url('assets/admin/libs/dropzone/min/dropzone.min.js');?>"></script>
