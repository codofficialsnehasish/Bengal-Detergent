        <!-- Magnific Popup-->
        <script src="<?= base_url('assets/admin/libs/magnific-popup/jquery.magnific-popup.min.js');?>"></script>

        <!-- Tour init js-->
        <script src="<?= base_url('assets/admin/js/pages/lightbox.init.js');?>"></script>
