<script src="<?= base_url('assets/admin/libs/parsleyjs/parsley.min.js');?>"></script>

<script src="<?= base_url('assets/admin/js/pages/form-validation.init.js');?>"></script>

        <!--tinymce js-->
<script src="<?= base_url('assets/admin/libs/tinymce/tinymce.min.js');?>"></script>


<script src="<?= base_url('assets/admin/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js');?>"></script>
<!-- init js -->
<script src="<?= base_url('assets/admin/js/pages/form-editor.init.js');?>"></script>
<script src="<?= base_url('assets/admin/js/pages/form-advanced.init.js');?>"></script>